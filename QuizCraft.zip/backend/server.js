console.log('QuizCraft backend placeholder');
