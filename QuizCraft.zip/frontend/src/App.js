export default function App(){ return 'QuizCraft frontend placeholder'; }
