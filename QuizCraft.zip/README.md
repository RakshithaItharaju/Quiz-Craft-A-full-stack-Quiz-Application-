# QuizCraft
This is a minimal placeholder for the QuizCraft full-stack project.
